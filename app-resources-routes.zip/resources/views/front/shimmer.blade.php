@for($i = 0; $i < 5; $i++)
    <div class="col-lg d-sm-block d-xs-block p-10 mx-auto my-auto">
        <div class="profile-boxes">
            <article>
                <div class="line-img"></div>
                {{--<div class="line"></div>--}}
                <div class="shimmer"></div>
            </article>
        </div>
    </div>
@endfor