@extends('front.layouts.master')
@section('title','Shaadi – Tips and Articles')
@section('description', 'Browse through our informative blogs and articles to get enlightened with valuable and supportive tips related to online marriage in Pakistan.')

@push('style')
	{{--Style--}}
@endpush

@section('content')



@endsection

@push('script')

@endpush