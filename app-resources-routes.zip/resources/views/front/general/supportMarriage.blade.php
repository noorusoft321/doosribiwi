@extends('front.layouts.master')
@section('title','Support a Marriage')
@section('description', 'Join With Us In The Noble Cause Of Supporting A Marriage At DoosriBiwi.com To Help The Underprivileged Individuals To Fulfill Their Dreams Of Their Shaadi.')

@push('style')
	{{--Style--}}
@endpush

@section('content')

<main>
	<div class="container-xxl">
		<br>
        <h2 class="align-center font-weight-600"> Support a Marriage </h2>
       	<img class="img-align-center heading-border" src="{{asset('home_page/heading-border.png')}}">

		<div class="row">
		    <div class="col-md-9">
		        <div class="card about-height-hero">
		            <div class="card-body">
		                <p>Marriages are an amazing part of our lives. Involving unlimited excitement, celebration and happiness, weddings are an event, which every young man and woman looks forward to and dreams of. From early years, we start thinking about what kind of a person we would like to spend our lives with and how we would manage our relationships and make a perfect life. The dreams, desires and expectations not one person is free of them. We wonder, search and idealize people and relationships and look forward to the day we would be a part of them for real. Doosri Biwi helps people in finding a perfect match. For this purpose we have a 100% Free Online Matrimonial website DoosriBiwi.com based on purely eastern values. With hundreds of monthly satisfied customers, we are progressing through the heights of success and generating more happiness than anyone else in this industry. We are not a commercial marriage bureau which runs purely on profit. We are an organization and our motive is to help people. To achieve this purpose we are offering many free services to people such as this 100% Free Online Rishta Pakistani Website, free rishta meetings, free place for engagement, free place for nikkah, support for simple nikkah, etc.</p>
		            </div>
		        </div>
		        <!-- /.card-icon-component -->
		    </div>
		    <!-- /.col -->
		    <div class="col-md-3">
		        <div class="card about-height-hero">
		            <div class="card-body">
		                <img src="{{asset('customPages/normal/13450.png')}}" class="event-thumb" alt="">	
		            </div>
		        </div>
		        <!-- /.card-icon-component -->
		    </div>
		    <!-- /.col -->
		</div>
		<div class="row">
		    <div class="col-md-12">
		        <div class="card">
		            <div class="card-body">
					    <p><br>
					        We only charge fee from those who want to hire us for personalized matchmaking in which our time and energy is spend to find a good match. This personalized matchmaking is a time taking process but it saves time of our client so we only charge fee for this service.</p>
					    <p>Marriages are an amazing part of our lives. Involving unlimited excitement, celebration and happiness, weddings are an event, which every young man and woman looks forward to and dreams of. From early years, we start thinking about what kind of a person we would like to spend our lives with and how we would manage our relationships and make a perfect life. The dreams, desires and expectations not one person is free of them. We wonder, search and idealize people and relationships and look forward to the day we would be a part of them for real.</p>
					    <p><strong>Marriage</strong>&nbsp;is a norm, which is above the bonds of our class system. That being the case, the underprivileged should have as much right to a time of excitement, and celebration as does any other privileged class in our society.</p>
					    <p>Keeping the same thought in mind,&nbsp;<strong>DoosriBiwi.com</strong>&nbsp;has vowed to aid and support any deserving family or under privileged individual who is ready to settle down in marital life. Our&nbsp;<strong>online marriage</strong>&nbsp;portal invites individuals from all the classes to register and look for a life partner.</p>
					    <p>Our support a&nbsp;<strong>marriage</strong>&nbsp;program is all about helping the underprivileged. From aiding in arranging for any home making necessities that the bride would want to bring with her to the new life, to arranging for a Valima dinner,&nbsp;<strong>Shaadi</strong>&nbsp;team welcomes all the support from its supporters and members.</p>
					    <p>We, at&nbsp;<strong>DoosriBiwi.com</strong>, want its members and fans to extend their hands and help us arrange marriages of such people by supporting us with financial aids. Our team has taken a pledge to help those couples who want to tie their wedding knot or their parents who are unable to gather enough funds to conduct the&nbsp;<strong>marriage</strong>&nbsp;ceremony.</p>
					    <p>WHAT BETTER WAY TO CONTRIBUTE TO A SOCIETY THAN TO HELP MAKE LIFE OF OTHERS AS BLISSFUL AS OURS! SO JOIN HANDS IN THIS HONORABLE CAUSE TODAY.</p>
					</div>
		        </div>
		        <!-- /.card-icon-component -->
		    </div>
		    <!-- /.col -->
		</div>
	</div>
</main>

@endsection

@push('script')

@endpush