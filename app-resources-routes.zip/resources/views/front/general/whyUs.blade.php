@extends('front.layouts.master')
@section('title','Why Us')
@section('description', 'Be A Part Of The Most Exclusive Online Marriage Bureau In Pakistan Where Your Future Life Partner’s Profile Awaits You.')

@push('style')
	{{--Style--}}
@endpush

@section('content')

<main>
	<div class="container-xxl">
		<br>
        <h2 class="align-center font-weight-600"> Why Us </h2>
       	<img class="img-align-center heading-border" src="{{asset('home_page/heading-border.png')}}">

		<div class="row">
		    <div class="col-md-9">
		        <div class="card about-height-hero">
		            
		            <div class="card-body">
					    Some men see things as they are, and say why. I dream of things that never were, and say why not. <br> <br>
					    Make Your Dream Come To Life. Now your desired life partner profile awaits you on this online marriage portal. Simply log on to discover how many men &amp; women share your likes and interests and find the perfect one! DoosriBiwi.com offers you a platform for Shaadi that enables you to interact with the favorite profile individuals and find out if they really are the perfect to be spouses you were looking for. <br> <br>
					    Still wondering why you should register? <br> <br>
					    Here are a few reasons that will surely compel you to join Today
					</div>
		        </div>
		        <!-- /.card-icon-component -->
		    </div>
		    <!-- /.col -->
		    <div class="col-md-3">
		        <div class="card about-height-hero">
		            <div class="card-body">
						<img src="{{asset('customPages/normal/35035.png')}}" class="event-thumb" alt="">		            
					</div>
		        </div>
		        <!-- /.card-icon-component -->
		    </div>
		    <!-- /.col -->
		</div>
		<div class="row">
		    <div class="col-md-12">
		    	<div class="card">
			        <div class="card-body">
					    <p>Match Guarantee</p>
					    <p>Hosting thousands of profiles online, there is no way you won’t find you prefect partner! Just seek the profiles which fulfill your desired requirements and you will definitely find someone special.</p>
					    <h3>Specific to Pakistani’s only</h3>
					    <p>DoosriBiwi.com is a&nbsp;<strong>Muslim marriage site</strong>, specific for Pakistanis only. We extend our services only to our Pakistani families here in Pakistan and those settled abroad. Pakistanis searching for spouses with similar culture can easily become our member and escape the trouble of screening the profiles.</p>
					    <h3>Strict Profile Screening</h3>
					    <p><strong>www.DoosriBiwi.com</strong>&nbsp;strongly supports individual privacy. Our member profiles are kept private and are safeguarded with top of the line safety apps and locks. Fake profile screening is the first step in our membership registration process. Our members are all original and real life people searching for a Pakistani&nbsp;<strong>rishta online</strong>.</p>
					    <h3>Complete security ~ Safety Privacy Security</h3>
					    <p>Strict measures have been taken on-site to protect the profile information of our members. Read on more about these measures at&nbsp;<strong><a href="https://www.DoosriBiwi.com/safety-security-and-privacy/" title="Safety Security And Privacy">www.DoosriBiwi.com/Safety Security Privacy</a></strong>.</p>
					    <h3>Short listing</h3>
					    <p>Members can short list their favorite profiles as they move on with the selection process of&nbsp;<strong>Shaadi</strong>. Each member shall be provided with a dashboard to support such functions.</p>
					    <h3>Dedicated Staff</h3>
					    <p>Our&nbsp;<strong>Pakistan matrimony</strong>&nbsp;staff sincerely works around the clock to interact, register and monitor all the member activities on-site. The counseling staff is here 24/7 to provide couples with marriage therapy and experienced guidance.</p>
					    <h3>Faster Communication</h3>
					    <p>We offer a prompt communication portal for the members. Your queries to the site managers and any request for interaction with a member are immediately communicated to the desired person.</p>
					    <h3>In-house Meeting Arrangement</h3>
					    <p><strong>DoosriBiwi.com</strong>&nbsp;emphasizes on mutual trust in match making. After the members have decided upon a favorite profile, the families are invited to meet in our office premises for further interaction and understanding.</p>
					    <h3>Complete Marriage solution</h3>
					    <p><strong>DoosriBiwi.com</strong>&nbsp;is an exclusive&nbsp;<strong>online marriage</strong>&nbsp;portal that provides you with ALL THAT YOU NEED for your Big Day! From matchmaking to the finalized rishta and&nbsp;<strong>marriage</strong>&nbsp;planning to services discount, we offer the ultimate packages to our exclusive members.</p>
					    <h3>Partner’s Discount</h3>
					    <p>Now find all the products and services on one single&nbsp;<strong>online marriage</strong>&nbsp;portal,&nbsp;<strong>DoosriBiwi.com</strong>. Whether it is shopping for the dress or buying shoes, booking the venue or deciding on photography, we offer you a host to&nbsp;help you manage all of that. Enjoy the great discounts from all the products and services offered by our branded partners and make your event more special!</p>
					</div>
				</div>
		        <!-- /.card-icon-component -->
		    </div>
		    <!-- /.col -->
		</div>
	</div>
</main>

@endsection

@push('script')

@endpush