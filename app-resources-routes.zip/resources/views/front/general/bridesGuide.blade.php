@extends('front.layouts.master')
@section('title','Brides Guide')
@section('description', 'DoosriBiwi.com Is An Ideal Online Marriage Platform For Pakistanis, Where You Can Find The Prettiest, Lineal And Educated Pakistani Girls For Marriage.')

@push('style')
	{{--Style--}}
@endpush

@section('content')

<main>
	<div class="container-xxl">
		<br>
        <h2 class="align-center font-weight-600"> Brides Guide </h2>
       	<img class="img-align-center heading-border" src="{{asset('home_page/heading-border.png')}}">

		<div class="row">
		    <div class="col-md-9">
		        <div class="card about-height-hero">
		            <div class="card-body">
					    They will simply stop calling brides beautiful after today. You have set the standards too high! Doosri Biwi helps people in finding a perfect match. For this purpose, we have a 100% Free Online Matrimonial website DoosriBiwi.com based on pure eastern values. With hundreds of monthly satisfied customers, we are progressing through the heights of success and generating more happiness than anyone else in this industry.
					    <br><br>
					    We are not a commercial marriage bureau which runs purely on profit; we are an organization and our motive is to help people. To achieve this purpose, we are offering many free services to people, such as this 100% Free Online Rishta Pakistani Website, free rishta meetings, free place for engagement, free place for nikkah, support for simple nikkah, etc.
					</div>
		        </div>
		        <!-- /.card-icon-component -->
		    </div>
		    <!-- /.col -->
		    <div class="col-md-3">
		        <div class="card about-height-hero">
		            <div class="card-body">
		                <img src="{{asset('customPages/normal/66060.png')}}" class="event-thumb" alt="">
		            </div>
		        </div>
		        <!-- /.card-icon-component -->
		    </div>
		    <!-- /.col -->
		</div>
		<div class="row">
		    <div class="col-md-12">
		        <div class="card">
		            <div class="card-body">
					    <h2><span style="font-size:14px">We only charge fee from those who want to hire us for personalized matchmaking in which our time and energy is spent to find a good match. This personalized matchmaking is a time taking process, but it saves time of our client so we only charge fee for this service.</span></h2>
					    <h2>Finding a Perfect Bride</h2>
					    <p>Every man wants a wife that is perfect in every way.&nbsp; Smart and beautiful, intelligent yet understanding, cooperative and a good homemaker; all of this defines an ideal life partner for men. But, is finding the perfect bride even remotely possible? The answer is yes. You just have to look in the right direction!</p>
					    <p>There are many myths in our subcontinent about how to judge a woman while you choosing for&nbsp;<strong>shaadi</strong>. Some say women who have a choti under hair is one who is most fertile; others say things like the woman with big feet are less active and more lazy. Some others say that to judge a girl see her grandmother, she will most probably be like her in her life style. Hence, a host of unbelievable myths are called upon once you come to ask the oldest of generation for an idea.</p>
					    <p>At the end of the day, we’re all human and no one is perfect. Finding the perfect young woman who will turn out to be the perfect Baho and Biwi is difficult but not impossible. All you have to do is look out for some of these pointers given below that will help you find the perfect Pakistani bride.</p>
					    <p><strong>Keep Your Intentions Clear</strong></p>
					    <p>When finding the perfect young woman for&nbsp;<strong>marriage</strong>, the first thing a man must do is to keep his intentions pure. You must remain true to yourself and ask yourself why you want to get married. If you look for a wife who would support you in managing the household then you definitely should not search for a 16 year old. Similarly, seek a woman who is a match for you as well as for your family. To find a good woman, you must keep your intentions pure and marry for love, companionship and happiness.</p>
					    <p><strong>The Age Difference Dilemma</strong></p>
					    <p>They say age is just a number and you are only as old as you feel. Well yes, that is quite right indeed. There is no specific age for falling in love. You might fall for someone in your teens and end up marrying her or you might find your true love in your thirties and spend the rest of your life with her. The traditional half the age bride concept is now less followed. So be rational. Find a partner who shares your ambition and ideals so that you two can build up a perfect happy life together. Furthermore, you must find a bride somewhere closer to your age. A difference of 1-8 years is ideal for&nbsp;<strong>marriage</strong>.</p>
					    <p><strong>Go for the Good Qualities</strong></p>
					    <p>When looking for a bride, make sure you search for someone with good character and qualities rather than a beautiful face. Always go for someone who is decent, kind and down to earth. Such a woman will prove to be a loving and faithful life partner. However, unless you converse with her live, you will not be able to know her well before you make the decision. Here, we offer our premium membership chat portal where you can get to know each other well. Go for the qualities that can help you build a perfect relationship considering the future years plan for your family.</p>
					    <p><strong>Approach Her in a Respectable Manner</strong></p>
					    <p><strong>DoosriBiwi.com</strong>&nbsp;offers to provide its members a chance to chat with the prospect bride to be. This way you get to understand each other and confirm whether you are making the right decision.&nbsp;Whenever you approach a woman with a&nbsp;<strong>marriage</strong>&nbsp;proposal, make sure you approach her in a decent manner and lay your cards on the table. Also, remember never to rush her to make a decision since&nbsp;<strong>shaadi</strong>&nbsp;is not a joke. Spending a lifetime with someone is not easy and many issues need to be taken into consideration.</p>
					    <p>Today, you can save yourself from all the frustration of the bride search; and embarrassment of going house to house and not returning call when you just don’t find the Right One. Now you can create your profile online and search for the perfect life partner online. Whether you are looking to marry a 16 year old girl or searching for a woman perfect for second marriage, simply look in our profile directory, which is in fact the largest directory of&nbsp;<strong>online marriage</strong>&nbsp;and you will be amazed to find so many options.</p>
					</div>
		        </div>
		        <!-- /.card-icon-component -->
		    </div>
		    <!-- /.col -->
		</div>
	</div>
</main>

@endsection

@push('script')

@endpush